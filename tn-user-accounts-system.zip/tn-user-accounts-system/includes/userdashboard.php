<?php
include("config.php");
?>
<p>This is user dashboard page</p>